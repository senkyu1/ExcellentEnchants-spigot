package id.myserver.actionbarinfo;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ActionBarCommand implements CommandExecutor, TabCompleter {

    private final ActionBarInfo plugin;
    private static final List<String> SUBCOMMANDS = Arrays.asList(
            "reload", "toggle", "on", "off", "resetday", "setday");

    public ActionBarCommand(ActionBarInfo plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <reload|toggle|on|off|resetday|setday> [player] [angka]");
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload" -> handleReload(sender);
            case "toggle" -> handleToggle(sender, args, null);
            case "on" -> handleToggle(sender, args, true);
            case "off" -> handleToggle(sender, args, false);
            case "resetday" -> handleResetDay(sender);
            case "setday" -> handleSetDay(sender, args);
            default -> sender.sendMessage(ChatColor.RED + "Subcommand tidak dikenal. Pakai: reload, toggle, on, off, resetday, setday");
        }
        return true;
    }

    private boolean hasAdmin(CommandSender sender) {
        if (!sender.hasPermission("actionbarinfo.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk itu.");
            return false;
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        if (!hasAdmin(sender)) return;
        plugin.loadConfigValues();
        sender.sendMessage(ChatColor.GREEN + "ActionBarInfo config berhasil di-reload.");
    }

    /**
     * forceState: null = toggle, true = paksa nyala, false = paksa mati
     */
    private void handleToggle(CommandSender sender, String[] args, Boolean forceState) {
        Player target;

        if (args.length >= 2) {
            // /actionbarinfo toggle <player>  -> butuh admin karena ubah orang lain
            if (!hasAdmin(sender)) return;
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player '" + args[1] + "' tidak online.");
                return;
            }
        } else {
            // /actionbarinfo toggle  -> buat diri sendiri
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Sertakan nama player: /actionbarinfo " + args[0] + " <player>");
                return;
            }
            if (!sender.hasPermission("actionbarinfo.toggle")) {
                sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin untuk itu.");
                return;
            }
            target = (Player) sender;
        }

        boolean newState = (forceState != null) ? forceState : !plugin.isEnabled(target);
        plugin.setEnabled(target, newState);

        String status = newState ? ChatColor.GREEN + "AKTIF" : ChatColor.RED + "MATI";
        if (target.equals(sender)) {
            sender.sendMessage(ChatColor.YELLOW + "Action bar kamu sekarang: " + status);
        } else {
            sender.sendMessage(ChatColor.YELLOW + "Action bar " + target.getName() + " sekarang: " + status);
            target.sendMessage(ChatColor.YELLOW + "Action bar kamu di-set " + status + ChatColor.YELLOW + " oleh " + sender.getName());
        }
    }

    private void handleResetDay(CommandSender sender) {
        if (!hasAdmin(sender)) return;
        plugin.resetDay();
        sender.sendMessage(ChatColor.GREEN + "Hitungan Day sudah direset ke Day 1.");
    }

    private void handleSetDay(CommandSender sender, String[] args) {
        if (!hasAdmin(sender)) return;
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /actionbarinfo setday <angka>");
            return;
        }
        try {
            long value = Long.parseLong(args[1]);
            if (value < 1) {
                sender.sendMessage(ChatColor.RED + "Angka Day minimal 1.");
                return;
            }
            plugin.setDay(value);
            sender.sendMessage(ChatColor.GREEN + "Hitungan Day sekarang di-set ke Day " + value + ".");
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "'" + args[1] + "' bukan angka yang valid.");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBCOMMANDS) {
                if (s.startsWith(args[0].toLowerCase())) result.add(s);
            }
        } else if (args.length == 2 && Arrays.asList("toggle", "on", "off").contains(args[0].toLowerCase())) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) result.add(p.getName());
            }
        }
        return result;
    }
}
