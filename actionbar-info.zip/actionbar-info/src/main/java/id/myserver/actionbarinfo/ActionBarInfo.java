package id.myserver.actionbarinfo;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.geysermc.floodgate.api.FloodgateApi;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class ActionBarInfo extends JavaPlugin {

    private BukkitTask task;
    private long updateInterval;
    private String javaFormat;
    private String bedrockFormat;
    private boolean floodgateAvailable;

    // --- Data yang dipersist (data.yml) ---
    private File dataFile;
    private FileConfiguration dataConfig;
    private long dayOffset = 0L;
    private final Set<UUID> disabledPlayers = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();
        loadData();

        floodgateAvailable = Bukkit.getPluginManager().isPluginEnabled("floodgate");
        if (!floodgateAvailable) {
            getLogger().warning("Floodgate tidak terdeteksi. Semua player akan dianggap Java Edition.");
        }

        ActionBarCommand command = new ActionBarCommand(this);
        getCommand("actionbarinfo").setExecutor(command);
        getCommand("actionbarinfo").setTabCompleter(command);

        startTask();
        getLogger().info("ActionBarInfo aktif! Update tiap " + updateInterval + " tick.");
    }

    @Override
    public void onDisable() {
        if (task != null) {
            task.cancel();
        }
        saveData();
    }

    // ================== CONFIG (format tampilan) ==================

    public void loadConfigValues() {
        reloadConfig();
        updateInterval = getConfig().getLong("update-interval-ticks", 20L);
        javaFormat = getConfig().getString("format-java",
                "&fX:%x% Y:%y% Z:%z% &7| &eDay %day% &7| &b⏰ %time%");
        bedrockFormat = getConfig().getString("format-bedrock", "&eDay %day%");

        if (task != null) {
            task.cancel();
            startTask();
        }
    }

    // ================== DATA (day offset & toggle player) ==================

    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            getDataFolder().mkdirs();
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                getLogger().severe("Gagal membuat data.yml: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        dayOffset = dataConfig.getLong("day-offset", 0L);

        disabledPlayers.clear();
        List<String> saved = dataConfig.getStringList("disabled-players");
        for (String uuidStr : saved) {
            try {
                disabledPlayers.add(UUID.fromString(uuidStr));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveData() {
        if (dataConfig == null || dataFile == null) return;
        dataConfig.set("day-offset", dayOffset);
        List<String> list = disabledPlayers.stream().map(UUID::toString).toList();
        dataConfig.set("disabled-players", list);
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Gagal menyimpan data.yml: " + e.getMessage());
        }
    }

    /** World acuan buat hitungan hari (dunia utama/overworld pertama). */
    private World referenceWorld() {
        return Bukkit.getWorlds().get(0);
    }

    private long realDay() {
        return referenceWorld().getFullTime() / 24000L;
    }

    /** Hari yang ditampilkan ke player, mulai dari 1. */
    public long getDisplayDay() {
        return (realDay() - dayOffset) + 1;
    }

    /** Reset hitungan hari ke Day 1, tanpa mengubah waktu asli dunia. */
    public void resetDay() {
        dayOffset = realDay();
        saveData();
    }

    /** Set hitungan hari ke angka tertentu (buat lanjutin day setelah reset). */
    public void setDay(long targetDay) {
        dayOffset = realDay() - (targetDay - 1);
        saveData();
    }

    public boolean isEnabled(Player p) {
        return !disabledPlayers.contains(p.getUniqueId());
    }

    public void setEnabled(Player p, boolean enabled) {
        if (enabled) {
            disabledPlayers.remove(p.getUniqueId());
        } else {
            disabledPlayers.add(p.getUniqueId());
        }
        saveData();
    }

    // ================== ACTION BAR ==================

    private void startTask() {
        task = Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (isEnabled(p)) {
                    sendActionBar(p);
                }
            }
        }, 0L, updateInterval);
    }

    private void sendActionBar(Player p) {
        World world = p.getWorld();
        long day = getDisplayDay();

        boolean isBedrock = false;
        if (floodgateAvailable) {
            try {
                isBedrock = FloodgateApi.getInstance().isFloodgatePlayer(p.getUniqueId());
            } catch (Throwable ignored) {
                isBedrock = false;
            }
        }

        String message;
        if (isBedrock) {
            message = bedrockFormat.replace("%day%", String.valueOf(day));
        } else {
            String time = formatTime(world.getTime());
            message = javaFormat
                    .replace("%day%", String.valueOf(day))
                    .replace("%x%", String.valueOf(p.getLocation().getBlockX()))
                    .replace("%y%", String.valueOf(p.getLocation().getBlockY()))
                    .replace("%z%", String.valueOf(p.getLocation().getBlockZ()))
                    .replace("%time%", time);
        }

        p.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                TextComponent.fromLegacyText(ChatColor.translateAlternateColorCodes('&', message)));
    }

    /**
     * Konversi world time (0-24000) ke format jam:menit ala Minecraft.
     * Ticks 0 = jam 06:00 pagi.
     */
    private String formatTime(long ticks) {
        long time = ticks % 24000;
        long hour = ((time / 1000) + 6) % 24;
        long minute = (time % 1000) * 60 / 1000;
        return String.format("%02d:%02d", hour, minute);
    }
}
